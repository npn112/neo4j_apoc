package apoc.result;

/**
 * @author mh
 * @since 26.02.16
 */
public class DoubleResult {
    public final Double value;

    public DoubleResult(Double value) {
        this.value = value;
    }
}
