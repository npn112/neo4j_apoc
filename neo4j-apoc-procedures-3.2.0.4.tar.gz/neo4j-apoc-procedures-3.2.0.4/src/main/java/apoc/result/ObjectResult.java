package apoc.result;

/**
 * @author mh
 * @since 26.02.16
 */
public class ObjectResult {
    public final Object value;

    public ObjectResult(Object value) {
        this.value = value;
    }
}
